You can't review answered MCQs in collegeboard... until now... wow crazy.

Built cause in an hour with chatgpt (45min debugging)

UX sucks but it works and I need to go study (hence the extension)

oh for usage just download the zip, unzip, and and lookup how to add chrome extension
  jk, go to chrome://extensions and load unpacked

  click on the extension and click "enable" to go through the questions (you'll have to write down your answers)
  click again and click "disable" to yk

the fact it shows whether you got the answer right or wrong originally is a feature, not a bug, so you can uh focus on that problem again mhm
